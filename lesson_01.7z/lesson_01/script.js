'use strict';

const productName = 'printer';
const productCount = 10;
const productCategory = 'HP';
const productPrice = 8000;

const productTotalPrice = productCount * productPrice;

console.log('productName: ', productName);

console.log(productTotalPrice);